document.getElementById('downloadBtn').addEventListener('click', function () {
  const text = 'Hello, this is a sample text file.\nYou can add multiple lines here.';
  const blob = new Blob([text], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'sample.txt';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
});
